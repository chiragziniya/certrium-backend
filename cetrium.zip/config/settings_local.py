"""Local/dev settings.

- Safe defaults
- Console email backend
- sqlite by default
"""

from __future__ import annotations

from .settings_base import *  # noqa

DJANGO_ENV = "local"
DEBUG = True

ALLOWED_HOSTS = env.list("ALLOWED_HOSTS", default=["localhost", "127.0.0.1"])  # noqa: F405

# Prefer sqlite locally unless DATABASE_URL is explicitly provided.
DATABASES = {
    "default": env.db(
        "DATABASE_URL",
        default=f"sqlite:///{(BASE_DIR / 'db.sqlite3').as_posix()}",  # noqa: F405
    )
}

EMAIL_BACKEND = env(
    "EMAIL_BACKEND",
    default="django.core.mail.backends.console.EmailBackend",
)

# Make local development easier.
CORS_ALLOW_ALL_ORIGINS = env_bool("CORS_ALLOW_ALL_ORIGINS", default=True)
